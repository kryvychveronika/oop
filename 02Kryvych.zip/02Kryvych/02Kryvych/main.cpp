//  Created by Veronika on 23.04.2025.

#include <iostream>
#include <cassert>
#include "AComplex.h"
#include "TComplex.h"
#include <cmath>
using namespace std;

int main() {
    AComplex a1(3, 4), a2(1, -2);
    TComplex t1 = a1.toTComplex(), t2 = a2.toTComplex();

    // алгебраїчна форма
    AComplex add = a1 + a2;
    AComplex sub = a1 - a2;
    AComplex mul = a1 * a2;
    AComplex div = a1 / a2;

    // додавання
    AComplex expectedAdd(4, 2);
    assert(fabs(add.real - expectedAdd.real) < 1e-6 && fabs(add.im - expectedAdd.im) < 1e-6);

    // віднімання
    AComplex expectedSub(2, 6);
    assert(fabs(sub.real - expectedSub.real) < 1e-6 && fabs(sub.im - expectedSub.im) < 1e-6);

    // множення у тригонометричній формі
    AComplex expectedMul(11, -2);
    assert(fabs(mul.real - expectedMul.real) < 1e-6 && fabs(mul.im - expectedMul.im) < 1e-6);

    // ділення у тригонометричній формі
    AComplex expectedDiv(-1, 2);
    assert(fabs(div.real - expectedDiv.real) < 1e-6 && fabs(div.im - expectedDiv.im) < 1e-6);

    // додавання у тригонометричній і перевод в алгебраїчну
    TComplex tAdd = t1 + t2;
    AComplex aAdd = tAdd.toAComplex();
    assert(fabs(aAdd.real - expectedAdd.real) < 1e-6 && fabs(aAdd.im - expectedAdd.im) < 1e-6);

    // віднімання у тригонометричній і перевод в алгебраїчну
    TComplex tSub = t1 - t2;
    AComplex aSub = tSub.toAComplex();
    assert(fabs(aSub.real - expectedSub.real) < 1e-6 && fabs(aSub.im - expectedSub.im) < 1e-6);

    
    cout << "All tests passed." << "\n";
    return 0;
}

